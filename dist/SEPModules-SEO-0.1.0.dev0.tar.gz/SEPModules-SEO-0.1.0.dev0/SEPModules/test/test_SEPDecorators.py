"""
Author: Marcel Simader
Data: 01.04.2021
"""

if __name__ == "__main__":
	raise NotImplementedError()